package com.cg.jpastart.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "BOOK_MASTER")
public class Book implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private int bookId;

	@Column(length=20)
	private String title;
	@Column(length=10)
	private double price;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "books")
	private Set<Author> names = new HashSet<>();

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Set<Author> getOrders() {
		return names;
	}

	public void setOrders(Set<Author> orders) {
		this.names = orders;
	}

}
