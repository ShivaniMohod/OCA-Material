package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();

		// first define few books

		Book one = new Book();
		one.setBookId(21);
		one.setTitle("Al");
		one.setPrice(500);

		Book two = new Book();
		two.setBookId(22);
		two.setTitle("Veg");
		two.setPrice(350);

		Book three = new Book();
		three.setBookId(23);
		three.setTitle("Power");
		three.setPrice(150);

		Book four = new Book();
		four.setBookId(24);
		four.setTitle("Power");
		four.setPrice(250);

		// now define first author and add few books in it
		Author firstAuthor = new Author();
		firstAuthor.setAuthorId(2001);
		firstAuthor.setAuthorName("Paulo Coelho");

		firstAuthor.addBook(one);
		firstAuthor.addBook(two);

		// now define second author and add few books in it
		Author secondAuthor = new Author();
		secondAuthor.setAuthorId(2002);
		secondAuthor.setAuthorName("Michael Flocker");
		
		secondAuthor.addBook(three);
		secondAuthor.addBook(four);

		// save authors using entity manager

		em.persist(firstAuthor);
		em.persist(secondAuthor);

		System.out
				.println("Added authors along with order details to database.");

		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}
