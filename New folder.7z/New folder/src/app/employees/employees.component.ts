import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../models/employee';
import { Router } from '@angular/router';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  newEmployee: EmployeeModel;
  constructor(private router: Router, private empService: EmployeeService) {
      this.newEmployee = new EmployeeModel();
   }

  ngOnInit() {
  }
  addEmployee() {
    this.empService.add(this.newEmployee);
  }
  goBack() {
    this.router.navigate(['/Home']);
  }
}
