import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../services/employee.service';
import { EmployeeModel } from '../models/employee';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {
  allEmployees: EmployeeModel[];
  confirmationStatus;

  constructor(private router: Router, private empService: EmployeeService) {
    this.allEmployees = [];
    this.allEmployees = this.empService.display();
  }

  ngOnInit() {
  }
  addEmployee() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['/Employees']);
  }
  deleteEmployee(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.empService.delete(index);
    }
  }
  editList(index: number) {
    this.empService.editList(index);
  }
}
