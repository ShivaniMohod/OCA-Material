import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ListComponent } from './list/list.component';
import { UpdateEmployeesComponent } from './update-employees/update-employees.component';
import { EmployeesComponent } from './employees/employees.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'Home', component: HomeComponent},
  { path: 'Login', component: LoginComponent},
  { path: 'List', component: ListComponent},
  { path: 'Employees', component: EmployeesComponent},
  { path: 'UpdateEmployees', component: UpdateEmployeesComponent},
  { path: '**', redirectTo: '/home', pathMatch: 'full'}
];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
