export class LoginCredentialsModel {
    public email: String;
    public password: String;
}
