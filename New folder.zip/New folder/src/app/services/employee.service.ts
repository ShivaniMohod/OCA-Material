import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeModel } from '../models/employee';

@Injectable({
  providedIn: 'root'
})

export class EmployeeService {
  empArray: EmployeeModel[];
  constructor(private router: Router) {
    this.empArray = [];
  }
  add(emp: EmployeeModel) {
    // add task to array
    this.empArray.push(emp);
    this.router.navigate(['/List']);
  }
  display() {
    return this.empArray;
  }
  delete(index: number) {
    // delete a particular task
    this.empArray.splice(index, 1);
  }
  editList(index: number) {
    // add id of task through route to prefill and edit particular task
  this.router.navigate(['/updateEmployees'], { queryParams: { id: index }});
  }
  getDetailsOf(index) {
    // get details of particular task
    return this.empArray[index];
  }
  edit(index: number, updatedList: EmployeeModel) {
    // update edited task details to array
    this.empArray[index] = updatedList;
    this.router.navigate(['/list']);
  }
}
