import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-employees',
  templateUrl: './update-employees.component.html',
  styleUrls: ['./update-employees.component.css']
})
export class UpdateEmployeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
