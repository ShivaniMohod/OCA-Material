import { Component, OnInit } from '@angular/core';
import { UserDetailsModel } from '../models/user-details';
import { Router } from '@angular/router';
import { UserDetailsService } from '../services/user.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})

export class AddComponent implements OnInit {
  allUser: UserDetailsModel[];
  confirmationStatus: boolean;
  constructor(private router: Router, private userService: UserDetailsService) {
    this.allUser = [];
    this.allUser = this.userService.display();
  }
  ngOnInit() {
  }
  addUser() {
    this.router.navigate(['/details']);
  }
  deleteUser(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.userService.delete(index);
    }
  }
  editUser(index: number) {
    this.userService.editDetails(index);
  }
  getDetailsOf(index) {
    // get details of particular user
    return this.allUser[index];
  }
  edit(index: number, updatedDetails: UserDetailsModel) {
    // update edited user details to array
    this.allUser[index] = updatedDetails;
    this.router.navigate(['/add']);
  }
  logOff() {
    this.router.navigate(['/login']);
  }
}
