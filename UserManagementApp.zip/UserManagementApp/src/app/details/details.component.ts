import { Component, OnInit, Input } from '@angular/core';
import { UserDetailsModel } from '../models/user-details';
import { UserDetailsService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  constructor(private router: Router, private userService: UserDetailsService) {
    this.input = new UserDetailsModel();
    this.input.firstName = '';
    this.input.lastName = '';
    this.input.email = '';

  }
  input: UserDetailsModel;

navigateToAdd() {
  // navigate to add page on click of Go to add button
  this.router.navigate(['/add']);
}

saveUser() {
  this.userService.saveUser(this.input);
}

addUser() {
  this.userService.add(this.input);
}

clear() {
  this.input.firstName = '';
    this.input.lastName = '';
    this.input.email = '';

}
ngOnInit() {
}

}
