export class UserDetailsModel {

    public firstName: String;
    public lastName: String;
    public email: String;
}
