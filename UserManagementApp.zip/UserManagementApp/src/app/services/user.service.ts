import { Injectable } from '@angular/core';
import { UserDetailsModel } from '../models/user-details';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {
userArray: UserDetailsModel[];
  constructor(private router: Router) {
    this.userArray = [];
  }
  add(u: UserDetailsModel) {
    // add user to array
    this.userArray.push(u);
    this.router.navigate(['/add']);
  }
  saveUser(u: UserDetailsModel) {
    this.userArray.push(u);
    this.router.navigate(['/add']);
  }
  display() {
    return this.userArray;
  }
  delete(index: number) {
    // delete a particular user
    this.userArray.splice(index, 1);
  }
  editDetails(index: number) {
    // add id of user through route to prefill and edit particular user
  this.router.navigate(['/edit'], { queryParams: { id: index }});
  }
  getDetailsOf(index) {
    // get details of particular user
    return this.userArray[index];
  }
  edit(index: number, updatedDetails: UserDetailsModel) {
    // update edited user details to array
    this.userArray[index] = updatedDetails;
    this.router.navigate(['/add']);
  }
}
